
 
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
 
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Raytracer.cpp : Defines the entry point for the console application.
#define _CRT_SECURE_NO_WARNINGS // for Visual Studio 2017 (maybe 2015 as well)

#include <iostream>
#include <vector>

#include "Vector.h"

#define M_PI 3.14159265359


void save_image(const char* filename, const unsigned char* tableau, int w, int h) { // (0,0) is top-left corner
 
    FILE *f;
 
    int filesize = 54 + 3 * w*h;
 
    unsigned char bmpfileheader[14] = { 'B','M', 0,0,0,0, 0,0, 0,0, 54,0,0,0 };
    unsigned char bmpinfoheader[40] = { 40,0,0,0, 0,0,0,0, 0,0,0,0, 1,0, 24,0 };
    unsigned char bmppad[3] = { 0,0,0 };
 
    bmpfileheader[2] = (unsigned char)(filesize);
    bmpfileheader[3] = (unsigned char)(filesize >> 8);
    bmpfileheader[4] = (unsigned char)(filesize >> 16);
    bmpfileheader[5] = (unsigned char)(filesize >> 24);
 
    bmpinfoheader[4] = (unsigned char)(w);
    bmpinfoheader[5] = (unsigned char)(w >> 8);
    bmpinfoheader[6] = (unsigned char)(w >> 16);
    bmpinfoheader[7] = (unsigned char)(w >> 24);
    bmpinfoheader[8] = (unsigned char)(h);
    bmpinfoheader[9] = (unsigned char)(h >> 8);
    bmpinfoheader[10] = (unsigned char)(h >> 16);
    bmpinfoheader[11] = (unsigned char)(h >> 24);
 
    f = fopen(filename, "wb");
    fwrite(bmpfileheader, 1, 14, f);
    fwrite(bmpinfoheader, 1, 40, f);
    unsigned char *row = new unsigned char[w * 3];
    for (int i = 0; i < h; i++)
    {
        for (int j = 0; j < w; j++) {
            row[j * 3] = tableau[(w*(h - i - 1) * 3) + j * 3+2];
            row[j * 3+1] = tableau[(w*(h - i - 1) * 3) + j * 3+1];
            row[j * 3+2] = tableau[(w*(h - i - 1) * 3) + j * 3];
        }
        fwrite(row, 3, w, f);
        fwrite(bmppad, 1, (4 - (w * 3) % 4) % 4, f);
    }
    fclose(f);
    delete[] row;
}
 

 


int main() {
    int W = 1024;
    int H = 1024;
    double fov = 60 * M_PI / 180;
    
    Sphere s1(Vector(0,0, -50),20, Vector (1,0,0));
    Sphere s2(Vector(0,-2000-20, 0),2000, Vector (1,1,1)); //ground
    Sphere s3(Vector(0,2000+100, 0),2000, Vector (1,1,1)); //ceiling
    Sphere s4(Vector(-2000-50,0, 0),2000, Vector (1,1,1)); // left wall
    Sphere s5(Vector(2000+50,0, 0),2000, Vector (1,1,1)); // right wall
    Sphere s6(Vector(0, 0, -2000-100),2000, Vector (1,1,1)); // back wall
    
    Scene s;
    s.addSphere(s1);
    s.addSphere(s2);
    s.addSphere(s3);
    s.addSphere(s4);
    s.addSphere(s5);
    s.addSphere(s6);


    Vector light_position(15, 70, -30);
    double light_intensity = 1000000;
    
   
    std::vector<unsigned char> image(W*H * 3);
    for (int i = 0; i < H; i++) {
        for (int j = 0; j < W; j++) {
            
            Vector direction(j-W/2, i-H/2, -W/ (2*tan(fov/2)));
            direction.normalize();
            
            
            Ray r(Vector(0,0,0), direction);
            Vector P, N;
            
            int sphere_id;
            bool has_intersection = s.intersection(r, P,N, sphere_id);
            Vector pixel_intensity(0,0,0);
            if (has_intersection) {
                pixel_intensity = s.spheres[sphere_id].albedo * light_intensity * std::max(0., dot((light_position-P).getNormalized(), N))/ (light_position-P).getNorm2();
            }
            
 
            image[((H-i-1)*W + j) * 3 + 0] = std::min(255., std::max(0.,pixel_intensity[0]));
            image[((H-i-1)*W + j) * 3 + 1] = std::min(255., std::max(0.,pixel_intensity[1]));
            image[((H-i-1)*W + j) * 3 + 2] = std::min(255., std::max(0.,pixel_intensity[2]));
        }
    }
    save_image("seance1.bmp",&image[0], W, H);
 
    return 0;
}
