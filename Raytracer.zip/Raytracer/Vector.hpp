//
//  Vector.hpp
//  Raytracer
//
//  Created by Pauline Lemeille on 13/01/2020.
//  Copyright © 2020 Pauline Lemeille. All rights reserved.
//

#ifndef Vector_hpp
#define Vector_hpp

#include <stdio.h>

#endif /* Vector_hpp */
